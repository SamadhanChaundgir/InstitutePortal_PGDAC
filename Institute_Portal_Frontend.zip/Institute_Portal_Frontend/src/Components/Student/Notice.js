import React from "react";

export default function Notice() {
  return <div>Notice</div>;
}
