import React from "react";
import { Toaster } from "react-hot-toast";

export default function StudentDashboard() {
  return (
    <>
      <div>StudentDashboard</div>{" "}
      <Toaster position="top-center" reverseOrder={false} />
    </>
  );
}
