import React from "react";
import AdminDashboard from "./AdminDashboard";

export default function AdminPath() {
  return <AdminDashboard />;
}

export function StudentRecords() {
  return <AdminDashboard />;
}

export function FacultyRecords() {
  return <AdminDashboard />;
}
export function ManageRecords() {
  return <AdminDashboard />;
}
