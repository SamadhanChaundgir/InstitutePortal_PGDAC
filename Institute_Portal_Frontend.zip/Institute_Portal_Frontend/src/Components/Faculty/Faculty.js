import React from "react";
import FacultyDashboard from "./FacultyDashboard";
import TabTest from "./TabTest";

export default function CreateQuiz() {
  return <FacultyDashboard />;
}

export function AddQuestions() {
  return <FacultyDashboard />;
}

export function AddNotes() {
  return <FacultyDashboard />;
}
export function SendNotice() {
  return <FacultyDashboard />;
}
export function SendRecording() {
  return <FacultyDashboard />;
}
export function SendStudyMaterial() {
  return <FacultyDashboard />;
}
