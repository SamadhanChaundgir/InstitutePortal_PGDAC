import React from "react";

export default function StreamMongo() {
  return (
    <video
      src="http://localhost:8080/videoView.mp4"
      controls
      width="400"
    ></video>
  );
}
